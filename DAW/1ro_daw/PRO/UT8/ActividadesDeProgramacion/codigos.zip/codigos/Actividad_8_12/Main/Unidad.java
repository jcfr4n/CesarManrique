package Main;

/**
 *
 * @author David
 */
public enum Unidad {
       CM, M
}
