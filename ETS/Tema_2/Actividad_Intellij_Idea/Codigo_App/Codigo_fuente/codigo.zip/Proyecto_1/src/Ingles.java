public class Ingles {

    static void imprimir(){

        System.out.println("This ¡Hello World!");
        System.out.println("goes in English");
        System.out.println("\n");

    }

}