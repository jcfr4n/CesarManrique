
public class Aleman {

    static void imprimir(){

        System.out.println("Dieses ¡Hallo Welt!");
        System.out.println("geht auf deutsch");
        System.out.println("\n");

    }

}
