package Main;

/**
 *
 * @author juancfm
 */
class Firma {
    private final String nombre;

    public Firma(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
