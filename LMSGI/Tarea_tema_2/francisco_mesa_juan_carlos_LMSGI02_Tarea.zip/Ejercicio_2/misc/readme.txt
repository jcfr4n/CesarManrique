2.- Diseñar y codificar una  página web personal.
Pueden aparecer cuáles son tus estudios, profesión o aficiones (pueden ser datos inventados). Utiliza etiquetas semánticas para organizar la página. Si quieres, puedes tomar como base este ejemplo.
Incluye, al menos, una fotografía, una tabla y algún enlace a una página externa.

