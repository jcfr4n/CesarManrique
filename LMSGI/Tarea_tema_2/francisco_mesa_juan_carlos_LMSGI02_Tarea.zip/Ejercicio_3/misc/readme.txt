3.- Crear un formulario que realice una petición de reserva de un hotel con las siguientes características:
Un campo para introducir cada uno de los siguientes datos: nombre, apellidos, teléfono de contacto, e-mail, número de noches.
Dos menús desplegables para recoger la fecha de entrada (día/mes).
Un botón de radio para elegir entre habitación simple, doble o matrimonio.
Un campo de selección múltiple (checkbox) que permita al usuario indicar si desea desayuno, comida, cena y/o cama supletoria.
Una caja de texto donde se puedan dejar comentarios.
Un botón para limpiar el formulario y otro para enviarlo.